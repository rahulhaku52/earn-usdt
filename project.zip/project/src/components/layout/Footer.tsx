import React from 'react';
import { Link } from 'react-router-dom';
import { Dices, Twitter, Instagram, Github } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="md:flex md:items-center md:justify-between">
          <div className="flex-shrink-0 mb-6 md:mb-0">
            <Link to="/" className="flex items-center space-x-2">
              <Dices className="h-8 w-8 text-purple-500" />
              <span className="text-xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">BetGaming</span>
            </Link>
            <p className="mt-2 text-sm text-gray-400">
              Play games, place bets, win rewards
            </p>
          </div>
          
          <div className="grid grid-cols-2 gap-8 md:gap-16">
            <div>
              <h3 className="text-sm font-semibold text-gray-300 tracking-wider uppercase">
                Platform
              </h3>
              <ul className="mt-4 space-y-4">
                <li>
                  <Link to="/games" className="text-base text-gray-400 hover:text-white">
                    Games
                  </Link>
                </li>
                <li>
                  <Link to="/wallet" className="text-base text-gray-400 hover:text-white">
                    Wallet
                  </Link>
                </li>
                <li>
                  <Link to="/" className="text-base text-gray-400 hover:text-white">
                    How it Works
                  </Link>
                </li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-sm font-semibold text-gray-300 tracking-wider uppercase">
                Connect
              </h3>
              <ul className="mt-4 space-y-4">
                <li>
                  <a href="#" className="text-base text-gray-400 hover:text-white flex items-center">
                    <Twitter className="h-5 w-5 mr-2" />
                    Twitter
                  </a>
                </li>
                <li>
                  <a href="#" className="text-base text-gray-400 hover:text-white flex items-center">
                    <Instagram className="h-5 w-5 mr-2" />
                    Instagram
                  </a>
                </li>
                <li>
                  <a href="#" className="text-base text-gray-400 hover:text-white flex items-center">
                    <Github className="h-5 w-5 mr-2" />
                    GitHub
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div className="mt-8 border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-base text-gray-400">
            &copy; {new Date().getFullYear()} BetGaming. All rights reserved.
          </p>
          <div className="mt-4 md:mt-0 flex space-x-6">
            <Link to="/" className="text-gray-400 hover:text-gray-300">
              Terms
            </Link>
            <Link to="/" className="text-gray-400 hover:text-gray-300">
              Privacy
            </Link>
            <Link to="/" className="text-gray-400 hover:text-gray-300">
              Cookies
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;