import React, { useState } from 'react';
import { Copy, X, Wallet } from 'lucide-react';
import Button from '../ui/Button';
import Card, { CardHeader, CardBody } from '../ui/Card';

interface DepositModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const WALLET_ADDRESS = 'TLBACu6vyaM2ZGg2kceWgD3mNh3iZNnvFU';

const DepositModal: React.FC<DepositModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(WALLET_ADDRESS);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <Card className="max-w-md w-full">
        <CardHeader className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-white flex items-center">
            <Wallet className="h-6 w-6 text-purple-500 mr-2" />
            Make a Deposit
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
        </CardHeader>
        
        <CardBody>
          <div className="space-y-6">
            <div>
              <p className="text-gray-300 mb-2">
                Please send your deposit to the following address:
              </p>
              <div className="bg-gray-800 p-4 rounded-lg flex items-center justify-between">
                <code className="text-purple-400 break-all">{WALLET_ADDRESS}</code>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={handleCopyAddress}
                  leftIcon={<Copy className="h-4 w-4" />}
                >
                  {copied ? 'Copied!' : 'Copy'}
                </Button>
              </div>
            </div>

            <div className="bg-purple-900/20 border border-purple-500/50 rounded-lg p-4">
              <p className="text-sm text-purple-300">
                Minimum deposit: $10
                <br />
                Your deposit will be processed after confirmation.
              </p>
            </div>

            <Button variant="primary" onClick={onClose} fullWidth>
              I've Made My Deposit
            </Button>
          </div>
        </CardBody>
      </Card>
    </div>
  );
};

export default DepositModal;