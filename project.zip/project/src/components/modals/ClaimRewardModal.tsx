import React, { useState } from 'react';
import { useWallet } from '../../contexts/WalletContext';
import Button from '../ui/Button';
import Input from '../ui/Input';
import { Gift, X } from 'lucide-react';

interface ClaimRewardModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ClaimRewardModal: React.FC<ClaimRewardModalProps> = ({ isOpen, onClose }) => {
  const [promoCode, setPromoCode] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const { claimReward, loading } = useWallet();

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    try {
      await claimReward(promoCode);
      setSuccess('$50 bonus added to your wallet!');
      setPromoCode('');
    } catch (err: any) {
      setError(err.message || 'Failed to claim reward');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-gray-800 rounded-lg max-w-md w-full">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-white flex items-center">
              <Gift className="h-6 w-6 text-purple-500 mr-2" />
              Claim Reward
            </h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-white transition-colors"
            >
              <X className="h-6 w-6" />
            </button>
          </div>

          {error && (
            <div className="mb-4 p-3 bg-red-900/50 border border-red-500 rounded-lg text-red-200 text-sm">
              {error}
            </div>
          )}

          {success && (
            <div className="mb-4 p-3 bg-green-900/50 border border-green-500 rounded-lg text-green-200 text-sm">
              {success}
            </div>
          )}

          <form onSubmit={handleSubmit}>
            <Input
              label="Promo Code"
              value={promoCode}
              onChange={(e) => setPromoCode(e.target.value)}
              placeholder="Enter your promo code"
              fullWidth
            />

            <Button
              type="submit"
              variant="primary"
              isLoading={loading}
              fullWidth
              className="mt-4"
            >
              Claim Reward
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ClaimRewardModal;