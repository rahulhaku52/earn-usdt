import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Lock, User } from 'lucide-react';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import Card, { CardHeader, CardBody } from '../components/ui/Card';

const AdminLoginPage: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { adminLogin, loading } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!username || !password) {
      setError('Please enter both username and password');
      return;
    }
    
    try {
      console.log('Submitting admin login with:', { username });
      await adminLogin(username, password);
      navigate('/admin/dashboard');
    } catch (err) {
      setError('Invalid credentials');
      console.error(err);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center py-12 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-900 to-black">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white">
            Admin Access
          </h2>
          <p className="mt-2 text-gray-400">
            Please verify your admin credentials
          </p>
        </div>
        
        <Card>
          <CardHeader>
            <h3 className="text-xl font-bold text-white text-center">Admin Login</h3>
          </CardHeader>
          
          <CardBody>
            <form onSubmit={handleSubmit}>
              {error && (
                <div className="mb-4 p-3 bg-red-900/50 border border-red-500 rounded-lg text-red-200 text-sm">
                  {error}
                </div>
              )}
              
              <Input
                label="Username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter admin username"
                leftIcon={<User className="h-5 w-5 text-gray-400" />}
                required
                fullWidth
              />
              
              <Input
                label="Password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter admin password"
                leftIcon={<Lock className="h-5 w-5 text-gray-400" />}
                required
                fullWidth
              />
              
              <Button
                type="submit"
                variant="primary"
                isLoading={loading}
                fullWidth
                className="mt-6"
              >
                Verify & Access
              </Button>
            </form>
          </CardBody>
        </Card>
      </div>
    </div>
  );
};

export default AdminLoginPage;