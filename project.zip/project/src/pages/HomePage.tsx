import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { DollarSign, ShieldCheck, Trophy, Users } from 'lucide-react';
import Button from '../components/ui/Button';
import Card, { CardBody } from '../components/ui/Card';

const HomePage: React.FC = () => {
  const { isAuthenticated } = useAuth();

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-gray-900 to-black"></div>
        <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/2346594/pexels-photo-2346594.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1')] bg-cover bg-center opacity-10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col items-center text-center">
          <h1 className="text-4xl md:text-6xl font-extrabold text-white mb-6">
            <span className="bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">Bet, Play, Win</span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mb-10">
            Join our gaming platform where you can bet against other players and win big rewards. Simple, secure, and thrilling.
          </p>
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
            {isAuthenticated ? (
              <Link to="/games">
                <Button variant="primary" size="lg" className="animate-pulse">
                  Play Now
                </Button>
              </Link>
            ) : (
              <>
                <Link to="/signup">
                  <Button variant="primary" size="lg">
                    Sign Up Free
                  </Button>
                </Link>
                <Link to="/login">
                  <Button variant="secondary" size="lg">
                    Login
                  </Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white mb-4">How It Works</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Our platform makes betting simple, transparent, and fun. Follow these steps to get started.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="transform transition-transform hover:scale-105">
              <CardBody>
                <div className="text-center">
                  <div className="inline-flex items-center justify-center p-4 bg-purple-600 rounded-full mb-4">
                    <DollarSign className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2">1. Deposit Funds</h3>
                  <p className="text-gray-400">
                    Add money to your wallet securely to start playing.
                  </p>
                </div>
              </CardBody>
            </Card>
            
            <Card className="transform transition-transform hover:scale-105 md:translate-y-4">
              <CardBody>
                <div className="text-center">
                  <div className="inline-flex items-center justify-center p-4 bg-purple-600 rounded-full mb-4">
                    <Users className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2">2. Find Opponents</h3>
                  <p className="text-gray-400">
                    Join a game or create your own and wait for challengers.
                  </p>
                </div>
              </CardBody>
            </Card>
            
            <Card className="transform transition-transform hover:scale-105">
              <CardBody>
                <div className="text-center">
                  <div className="inline-flex items-center justify-center p-4 bg-purple-600 rounded-full mb-4">
                    <Trophy className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2">3. Win & Cash Out</h3>
                  <p className="text-gray-400">
                    Play the game, win the bet, and withdraw your earnings.
                  </p>
                </div>
              </CardBody>
            </Card>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white mb-4">Platform Features</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Our betting platform offers a variety of features designed to enhance your gaming experience.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="flex flex-col md:flex-row items-start md:items-center bg-gray-700 rounded-lg p-6">
              <div className="flex-shrink-0 md:mr-6 mb-4 md:mb-0">
                <div className="p-3 bg-purple-600 rounded-lg">
                  <ShieldCheck className="h-6 w-6 text-white" />
                </div>
              </div>
              <div>
                <h3 className="text-xl font-bold text-white mb-2">Secure Betting</h3>
                <p className="text-gray-300">
                  All bets on our platform are protected and transparent. We use advanced security measures to ensure fair play.
                </p>
              </div>
            </div>
            
            <div className="flex flex-col md:flex-row items-start md:items-center bg-gray-700 rounded-lg p-6">
              <div className="flex-shrink-0 md:mr-6 mb-4 md:mb-0">
                <div className="p-3 bg-purple-600 rounded-lg">
                  <DollarSign className="h-6 w-6 text-white" />
                </div>
              </div>
              <div>
                <h3 className="text-xl font-bold text-white mb-2">Low Commission</h3>
                <p className="text-gray-300">
                  We take only a 5% commission on winnings, allowing you to keep more of your hard-earned money.
                </p>
              </div>
            </div>
            
            <div className="flex flex-col md:flex-row items-start md:items-center bg-gray-700 rounded-lg p-6">
              <div className="flex-shrink-0 md:mr-6 mb-4 md:mb-0">
                <div className="p-3 bg-purple-600 rounded-lg">
                  <Trophy className="h-6 w-6 text-white" />
                </div>
              </div>
              <div>
                <h3 className="text-xl font-bold text-white mb-2">Instant Rewards</h3>
                <p className="text-gray-300">
                  Winnings are immediately credited to your account. No waiting periods or complicated processes.
                </p>
              </div>
            </div>
            
            <div className="flex flex-col md:flex-row items-start md:items-center bg-gray-700 rounded-lg p-6">
              <div className="flex-shrink-0 md:mr-6 mb-4 md:mb-0">
                <div className="p-3 bg-purple-600 rounded-lg">
                  <Users className="h-6 w-6 text-white" />
                </div>
              </div>
              <div>
                <h3 className="text-xl font-bold text-white mb-2">Global Community</h3>
                <p className="text-gray-300">
                  Connect with players from around the world and challenge them to exciting games.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-br from-purple-900 to-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-6">Ready to Start Betting?</h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Join thousands of players already winning on our platform. Sign up now and get started with your first bet!
          </p>
          {isAuthenticated ? (
            <Link to="/games">
              <Button variant="primary" size="lg">
                Go to Games
              </Button>
            </Link>
          ) : (
            <Link to="/signup">
              <Button variant="primary" size="lg" className="animate-pulse">
                Sign Up Now
              </Button>
            </Link>
          )}
        </div>
      </section>
    </div>
  );
};

export default HomePage;