import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Mail, Lock, User } from 'lucide-react';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import Card, { CardHeader, CardBody, CardFooter } from '../components/ui/Card';

const SignupPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [error, setError] = useState('');
  const { signup, loading } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!email || !password || !username) {
      setError('Please fill out all fields');
      return;
    }
    
    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }
    
    try {
      await signup(email, password, username);
      navigate('/dashboard');
    } catch (err: any) {
      setError(err.message || 'Failed to create account');
      console.error(err);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center py-12 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-900 to-black">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white">
            Create Your Account
          </h2>
          <p className="mt-2 text-gray-400">
            Join our gaming platform and start betting
          </p>
        </div>
        
        <Card>
          <CardHeader>
            <h3 className="text-xl font-bold text-white text-center">Sign Up</h3>
          </CardHeader>
          
          <CardBody>
            <form onSubmit={handleSubmit}>
              {error && (
                <div className="mb-4 p-3 bg-red-900/50 border border-red-500 rounded-lg text-red-200 text-sm">
                  {error}
                </div>
              )}
              
              <Input
                label="Username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Choose a username"
                leftIcon={<User className="h-5 w-5 text-gray-400" />}
                required
                fullWidth
              />
              
              <Input
                label="Email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                leftIcon={<Mail className="h-5 w-5 text-gray-400" />}
                required
                fullWidth
              />
              
              <Input
                label="Password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Create a password"
                leftIcon={<Lock className="h-5 w-5 text-gray-400" />}
                required
                fullWidth
              />
              
              <div className="flex items-center mb-6">
                <input
                  id="agree-terms"
                  name="agree-terms"
                  type="checkbox"
                  className="h-4 w-4 rounded border-gray-600 bg-gray-700 text-purple-600 focus:ring-purple-500"
                  required
                />
                <label htmlFor="agree-terms" className="ml-2 block text-sm text-gray-300">
                  I agree to the <Link to="#" className="text-purple-400 hover:text-purple-300">Terms of Service</Link> and <Link to="#" className="text-purple-400 hover:text-purple-300">Privacy Policy</Link>
                </label>
              </div>
              
              <Button
                type="submit"
                variant="primary"
                isLoading={loading}
                fullWidth
              >
                Create Account
              </Button>
            </form>
          </CardBody>
          
          <CardFooter className="text-center">
            <p className="text-gray-400">
              Already have an account?{' '}
              <Link to="/login" className="text-purple-400 hover:text-purple-300 font-medium">
                Sign in
              </Link>
            </p>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default SignupPage;