import React from 'react';
import { Link } from 'react-router-dom';
import { AlignCenter, Home } from 'lucide-react';
import Button from '../components/ui/Button';

const NotFoundPage: React.FC = () => {
  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-gray-900 to-black px-4">
      <div className="text-center">
        <h1 className="text-9xl font-bold text-purple-500">404</h1>
        <div className="flex justify-center mt-4 mb-8">
          <div className="w-16 h-1 bg-gradient-to-r from-purple-500 to-pink-500 rounded"></div>
        </div>
        <h2 className="text-3xl font-bold text-white mb-4">Page Not Found</h2>
        <p className="text-gray-400 mb-8 max-w-md mx-auto">
          The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Link to="/">
            <Button variant="primary" leftIcon={<Home className="h-5 w-5" />}>
              Go Home
            </Button>
          </Link>
          <Link to="/games">
            <Button variant="secondary" leftIcon={<AlignCenter className="h-5 w-5" />}>
              View Games
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default NotFoundPage;