import React, { useState } from 'react';
import { useWallet } from '../contexts/WalletContext';
import Button from '../components/ui/Button';
import Card, { CardHeader, CardBody } from '../components/ui/Card';
import Input from '../components/ui/Input';
import { Check, X, DollarSign, Eye } from 'lucide-react';

const AdminDashboardPage: React.FC = () => {
  const { transactionRequests, approveTransaction, rejectTransaction, loading } = useWallet();
  const [selectedRequest, setSelectedRequest] = useState<string | null>(null);
  const [adminNote, setAdminNote] = useState('');
  const [viewProof, setViewProof] = useState<string | null>(null);

  const pendingRequests = transactionRequests.filter(req => req.status === 'pending');

  const handleApprove = async (requestId: string) => {
    try {
      await approveTransaction(requestId, adminNote);
      setSelectedRequest(null);
      setAdminNote('');
    } catch (error) {
      console.error('Error approving transaction:', error);
    }
  };

  const handleReject = async (requestId: string) => {
    try {
      await rejectTransaction(requestId, adminNote);
      setSelectedRequest(null);
      setAdminNote('');
    } catch (error) {
      console.error('Error rejecting transaction:', error);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white">Admin Dashboard</h1>
        <p className="text-gray-400">Manage deposit and withdrawal requests</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Pending Requests */}
        <Card>
          <CardHeader>
            <h2 className="text-xl font-bold text-white">Pending Requests</h2>
          </CardHeader>
          <CardBody>
            {pendingRequests.length > 0 ? (
              <div className="space-y-4">
                {pendingRequests.map(request => (
                  <div
                    key={request.id}
                    className={`p-4 rounded-lg border ${
                      selectedRequest === request.id
                        ? 'border-purple-500 bg-purple-900/20'
                        : 'border-gray-700 bg-gray-800'
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-white font-medium">
                          {request.type === 'deposit' ? 'Deposit' : 'Withdrawal'} Request
                        </p>
                        <p className="text-sm text-gray-400">
                          User ID: {request.userId}
                        </p>
                        <p className="text-sm text-gray-400">
                          Date: {new Date(request.timestamp).toLocaleString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-bold text-green-400">
                          ${request.amount.toFixed(2)}
                        </p>
                        {request.paymentProof && (
                          <Button
                            variant="secondary"
                            size="sm"
                            leftIcon={<Eye className="h-4 w-4" />}
                            onClick={() => setViewProof(request.paymentProof!)}
                            className="mt-2"
                          >
                            View Proof
                          </Button>
                        )}
                      </div>
                    </div>

                    {selectedRequest === request.id ? (
                      <div className="mt-4 space-y-4">
                        <Input
                          label="Admin Note"
                          value={adminNote}
                          onChange={(e) => setAdminNote(e.target.value)}
                          placeholder="Add a note (optional)"
                          fullWidth
                        />
                        <div className="flex space-x-2">
                          <Button
                            variant="success"
                            leftIcon={<Check className="h-4 w-4" />}
                            onClick={() => handleApprove(request.id)}
                            isLoading={loading}
                            fullWidth
                          >
                            Approve
                          </Button>
                          <Button
                            variant="danger"
                            leftIcon={<X className="h-4 w-4" />}
                            onClick={() => handleReject(request.id)}
                            isLoading={loading}
                            fullWidth
                          >
                            Reject
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <Button
                        variant="secondary"
                        onClick={() => setSelectedRequest(request.id)}
                        fullWidth
                        className="mt-4"
                      >
                        Review Request
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <DollarSign className="h-12 w-12 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-400">No pending requests</p>
              </div>
            )}
          </CardBody>
        </Card>

        {/* Transaction Statistics */}
        <Card>
          <CardHeader>
            <h2 className="text-xl font-bold text-white">Statistics</h2>
          </CardHeader>
          <CardBody>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-800 p-4 rounded-lg">
                <p className="text-gray-400 text-sm">Total Deposits</p>
                <p className="text-2xl font-bold text-white">
                  ${transactionRequests
                    .filter(r => r.type === 'deposit' && r.status === 'approved')
                    .reduce((sum, r) => sum + r.amount, 0)
                    .toFixed(2)}
                </p>
              </div>
              <div className="bg-gray-800 p-4 rounded-lg">
                <p className="text-gray-400 text-sm">Total Withdrawals</p>
                <p className="text-2xl font-bold text-white">
                  ${transactionRequests
                    .filter(r => r.type === 'withdraw' && r.status === 'approved')
                    .reduce((sum, r) => sum + r.amount, 0)
                    .toFixed(2)}
                </p>
              </div>
              <div className="bg-gray-800 p-4 rounded-lg">
                <p className="text-gray-400 text-sm">Pending Deposits</p>
                <p className="text-2xl font-bold text-white">
                  ${transactionRequests
                    .filter(r => r.type === 'deposit' && r.status === 'pending')
                    .reduce((sum, r) => sum + r.amount, 0)
                    .toFixed(2)}
                </p>
              </div>
              <div className="bg-gray-800 p-4 rounded-lg">
                <p className="text-gray-400 text-sm">Pending Withdrawals</p>
                <p className="text-2xl font-bold text-white">
                  ${transactionRequests
                    .filter(r => r.type === 'withdraw' && r.status === 'pending')
                    .reduce((sum, r) => sum + r.amount, 0)
                    .toFixed(2)}
                </p>
              </div>
            </div>
          </CardBody>
        </Card>
      </div>

      {/* Payment Proof Modal */}
      {viewProof && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-lg max-w-2xl w-full">
            <div className="p-4 border-b border-gray-700 flex justify-between items-center">
              <h3 className="text-lg font-bold text-white">Payment Proof</h3>
              <Button
                variant="secondary"
                size="sm"
                onClick={() => setViewProof(null)}
              >
                Close
              </Button>
            </div>
            <div className="p-4">
              <img
                src={viewProof}
                alt="Payment Proof"
                className="max-w-full rounded-lg"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboardPage;