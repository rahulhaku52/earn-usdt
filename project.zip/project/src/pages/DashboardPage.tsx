import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useWallet } from '../contexts/WalletContext';
import { useGames } from '../contexts/GamesContext';
import Button from '../components/ui/Button';
import Card, { CardHeader, CardBody } from '../components/ui/Card';
import { Activity, Award, Calendar, DollarSign, Gamepad2, Plus, Wallet } from 'lucide-react';

const DashboardPage: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { balance, transactions } = useWallet();
  const { games, createGame } = useGames();
  const [isCreatingGame, setIsCreatingGame] = useState(false);

  // Stats
  const gamesPlayed = games.filter(game => 
    game.status === 'completed' && (game.creatorId === user?.id || game.opponentId === user?.id)
  ).length;
  
  const gamesWon = games.filter(game => 
    game.status === 'completed' && game.winnerId === user?.id
  ).length;
  
  const winRate = gamesPlayed > 0 ? Math.round((gamesWon / gamesPlayed) * 100) : 0;

  // Recent transactions
  const recentTransactions = [...transactions].slice(0, 5);

  // Recent games
  const recentGames = [...games]
    .filter(game => game.creatorId === user?.id || game.opponentId === user?.id)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  const handleCreateGame = async () => {
    setIsCreatingGame(true);
    try {
      const game = await createGame();
      // Navigate to the game lobby
    } catch (error: any) {
      if (error.message === 'Please make a deposit first') {
        navigate('/wallet');
      } else {
        console.error('Error creating game:', error);
      }
    } finally {
      setIsCreatingGame(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white">Welcome, {user?.username}</h1>
        <p className="text-gray-400">Here's an overview of your activity</p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="bg-gradient-to-br from-purple-900 to-purple-700">
          <CardBody className="flex items-center space-x-4">
            <div className="p-3 bg-white/20 rounded-lg">
              <Wallet className="h-6 w-6 text-white" />
            </div>
            <div>
              <p className="text-white text-sm font-medium">Balance</p>
              <h3 className="text-2xl font-bold text-white">${balance.toFixed(2)}</h3>
            </div>
          </CardBody>
        </Card>
        
        <Card className="bg-gradient-to-br from-blue-900 to-blue-700">
          <CardBody className="flex items-center space-x-4">
            <div className="p-3 bg-white/20 rounded-lg">
              <Gamepad2 className="h-6 w-6 text-white" />
            </div>
            <div>
              <p className="text-white text-sm font-medium">Games Played</p>
              <h3 className="text-2xl font-bold text-white">{gamesPlayed}</h3>
            </div>
          </CardBody>
        </Card>
        
        <Card className="bg-gradient-to-br from-green-900 to-green-700">
          <CardBody className="flex items-center space-x-4">
            <div className="p-3 bg-white/20 rounded-lg">
              <Award className="h-6 w-6 text-white" />
            </div>
            <div>
              <p className="text-white text-sm font-medium">Win Rate</p>
              <h3 className="text-2xl font-bold text-white">{winRate}%</h3>
            </div>
          </CardBody>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Activity */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="flex justify-between items-center">
              <h2 className="text-xl font-bold text-white flex items-center">
                <Activity className="mr-2 h-5 w-5 text-purple-400" />
                Recent Games
              </h2>
              <Button 
                variant="primary" 
                size="sm" 
                leftIcon={<Plus className="h-4 w-4" />}
                onClick={handleCreateGame}
                isLoading={isCreatingGame}
              >
                New Game
              </Button>
            </CardHeader>
            <CardBody>
              {recentGames.length > 0 ? (
                <div className="divide-y divide-gray-700">
                  {recentGames.map(game => {
                    const isCreator = game.creatorId === user?.id;
                    const opponent = isCreator ? game.opponentUsername : game.creatorUsername;
                    const hasWon = game.status === 'completed' && game.winnerId === user?.id;
                    const hasLost = game.status === 'completed' && game.winnerId !== user?.id && game.winnerId !== null;
                    
                    return (
                      <div key={game.id} className="py-4 flex items-center justify-between">
                        <div>
                          <div className="flex items-center space-x-3">
                            <div className={`p-2 rounded-full ${
                              game.status === 'waiting' ? 'bg-blue-900/50 text-blue-400' : 
                              game.status === 'active' ? 'bg-yellow-900/50 text-yellow-400' :
                              hasWon ? 'bg-green-900/50 text-green-400' : 
                              'bg-red-900/50 text-red-400'
                            }`}>
                              <Gamepad2 className="h-5 w-5" />
                            </div>
                            <div>
                              <p className="text-white font-medium">
                                {game.status === 'waiting' ? 'Waiting for opponent' :
                                 game.status === 'active' ? `Active game vs ${opponent}` :
                                 hasWon ? 'You won!' : 'You lost'}
                              </p>
                              <p className="text-gray-400 text-sm flex items-center">
                                <Calendar className="h-3 w-3 mr-1" />
                                {new Date(game.createdAt).toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                        </div>
                        <div>
                          <Link to={`/games/${game.id}`}>
                            <Button variant={
                              game.status === 'waiting' ? 'info' : 
                              game.status === 'active' ? 'warning' :
                              hasWon ? 'success' : 'danger'
                            } size="sm">
                              {game.status === 'waiting' || game.status === 'active' ? 'View Game' : 'Details'}
                            </Button>
                          </Link>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="py-6 text-center">
                  <p className="text-gray-400">No games yet. Start playing!</p>
                  <div className="mt-4">
                    <Button 
                      variant="primary" 
                      leftIcon={<Plus className="h-4 w-4" />}
                      onClick={handleCreateGame}
                      isLoading={isCreatingGame}
                    >
                      Create Game
                    </Button>
                  </div>
                </div>
              )}
              
              {recentGames.length > 0 && (
                <div className="mt-4">
                  <Link to="/games">
                    <Button variant="secondary" fullWidth>
                      View All Games
                    </Button>
                  </Link>
                </div>
              )}
            </CardBody>
          </Card>
        </div>

        {/* Recent Transactions */}
        <div>
          <Card>
            <CardHeader className="flex justify-between items-center">
              <h2 className="text-xl font-bold text-white flex items-center">
                <DollarSign className="mr-2 h-5 w-5 text-purple-400" />
                Recent Transactions
              </h2>
              <Link to="/wallet">
                <Button variant="secondary" size="sm">
                  Wallet
                </Button>
              </Link>
            </CardHeader>
            <CardBody>
              {recentTransactions.length > 0 ? (
                <div className="divide-y divide-gray-700">
                  {recentTransactions.map(transaction => (
                    <div key={transaction.id} className="py-3">
                      <div className="flex justify-between items-center">
                        <div>
                          <p className={`font-medium ${
                            transaction.amount > 0 ? 'text-green-400' : 'text-red-400'
                          }`}>
                            {transaction.amount > 0 ? '+' : ''}{transaction.amount.toFixed(2)} USD
                          </p>
                          <p className="text-gray-400 text-sm">{transaction.description}</p>
                        </div>
                        <span className="text-xs text-gray-500">
                          {new Date(transaction.timestamp).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-6 text-center">
                  <p className="text-gray-400">No transactions yet</p>
                </div>
              )}
              
              {recentTransactions.length > 0 && (
                <div className="mt-4">
                  <Link to="/wallet">
                    <Button variant="secondary" fullWidth>
                      View All Transactions
                    </Button>
                  </Link>
                </div>
              )}
            </CardBody>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;