import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useWallet } from '../contexts/WalletContext';
import { useAuth } from '../contexts/AuthContext';
import Button from '../components/ui/Button';
import Card, { CardHeader, CardBody } from '../components/ui/Card';
import Input from '../components/ui/Input';
import { Gamepad2, Dices, Trophy, Bot, Users, AlertTriangle } from 'lucide-react';

const GamingPage: React.FC = () => {
  const { user } = useAuth();
  const { balance, bonusAmount, hasDeposited } = useWallet();
  const navigate = useNavigate();
  const [betAmount, setBetAmount] = useState<number>(2);
  const [showDepositPrompt, setShowDepositPrompt] = useState(false);
  const [gameMode, setGameMode] = useState<'pvp' | 'ai' | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    if (balance + bonusAmount >= 50 && !hasDeposited) {
      setShowDepositPrompt(true);
    }
  }, [balance, bonusAmount, hasDeposited]);

  const handlePlayGame = () => {
    setError('');

    if (balance + bonusAmount >= 50 && !hasDeposited) {
      setShowDepositPrompt(true);
      return;
    }

    if (betAmount < 2 || betAmount > 5000) {
      setError('Bet amount must be between $2 and $5000');
      return;
    }

    if (betAmount > balance + bonusAmount) {
      setError('Insufficient balance');
      return;
    }

    // Navigate to game with selected mode and bet amount
    navigate(`/game/play?mode=${gameMode}&bet=${betAmount}`);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white flex items-center">
          <Gamepad2 className="mr-3 h-8 w-8 text-purple-500" />
          Gaming Arena
        </h1>
        <p className="text-gray-400">Challenge players or face our AI in intense matches</p>
      </div>

      {showDepositPrompt ? (
        <Card className="mb-8 bg-gradient-to-br from-red-900 to-red-800">
          <CardBody className="text-center py-12">
            <AlertTriangle className="h-16 w-16 text-red-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-4">Deposit Required</h2>
            <p className="text-gray-300 mb-6">
              You have ${bonusAmount.toFixed(2)} in bonus funds. Please deposit at least $10 to continue playing.
            </p>
            <Button
              variant="primary"
              size="lg"
              onClick={() => navigate('/wallet')}
            >
              Deposit Now
            </Button>
          </CardBody>
        </Card>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            <Card 
              className={`cursor-pointer transition-all duration-200 hover:scale-105 ${
                gameMode === 'pvp' ? 'ring-2 ring-purple-500' : ''
              }`}
              onClick={() => setGameMode('pvp')}
            >
              <CardBody className="text-center py-8">
                <Users className="h-12 w-12 text-purple-500 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">Player vs Player</h3>
                <p className="text-gray-400">
                  Challenge other players and compete for rewards
                </p>
              </CardBody>
            </Card>

            <Card 
              className={`cursor-pointer transition-all duration-200 hover:scale-105 ${
                gameMode === 'ai' ? 'ring-2 ring-purple-500' : ''
              }`}
              onClick={() => setGameMode('ai')}
            >
              <CardBody className="text-center py-8">
                <Bot className="h-12 w-12 text-purple-500 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">Player vs AI</h3>
                <p className="text-gray-400">
                  Test your skills against our advanced AI opponent
                </p>
              </CardBody>
            </Card>
          </div>

          <Card className="mb-8">
            <CardHeader>
              <h2 className="text-xl font-bold text-white">Game Settings</h2>
            </CardHeader>
            <CardBody>
              {error && (
                <div className="mb-4 p-3 bg-red-900/50 border border-red-500 rounded-lg text-red-200 text-sm">
                  {error}
                </div>
              )}

              <div className="space-y-6">
                <div>
                  <Input
                    label="Bet Amount"
                    type="number"
                    min={2}
                    max={5000}
                    value={betAmount}
                    onChange={(e) => setBetAmount(Number(e.target.value))}
                    placeholder="Enter bet amount"
                    fullWidth
                  />
                  <p className="mt-2 text-sm text-gray-400">
                    Min: $2 - Max: $5,000
                  </p>
                </div>

                <div className="flex items-center justify-between bg-gray-800 p-4 rounded-lg">
                  <div>
                    <div>
                      <p className="text-gray-300">Main Balance</p>
                      <p className="text-2xl font-bold text-white">${balance.toFixed(2)}</p>
                    </div>
                    {bonusAmount > 0 && (
                      <div className="mt-2">
                        <p className="text-gray-300">Bonus Balance</p>
                        <p className="text-2xl font-bold text-purple-400">${bonusAmount.toFixed(2)}</p>
                      </div>
                    )}
                  </div>
                  <div>
                    <p className="text-gray-300">Potential Win</p>
                    <p className="text-2xl font-bold text-green-400">
                      ${(betAmount * 1.9).toFixed(2)}
                    </p>
                  </div>
                </div>

                <Button
                  variant="primary"
                  size="lg"
                  fullWidth
                  leftIcon={<Trophy className="h-5 w-5" />}
                  onClick={handlePlayGame}
                  disabled={!gameMode}
                >
                  {gameMode ? 'Start Game' : 'Select Game Mode'}
                </Button>
              </div>
            </CardBody>
          </Card>
        </>
      )}
    </div>
  );
};

export default GamingPage;