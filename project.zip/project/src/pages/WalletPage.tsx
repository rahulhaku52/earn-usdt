import React, { useState, useRef } from 'react';
import { useWallet } from '../contexts/WalletContext';
import { useAuth } from '../contexts/AuthContext';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import Card, { CardHeader, CardBody } from '../components/ui/Card';
import { Wallet, ArrowUpRight, ArrowDownLeft, DollarSign, RefreshCw, FileText, Upload, Gift } from 'lucide-react';
import ClaimRewardModal from '../components/modals/ClaimRewardModal';

const WalletPage: React.FC = () => {
  const { balance, transactions, deposit, withdraw, loading, pendingBonus } = useWallet();
  const { user } = useAuth();
  const [depositAmount, setDepositAmount] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [activeTab, setActiveTab] = useState<'deposit' | 'withdraw' | 'history'>('deposit');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [paymentProof, setPaymentProof] = useState<string>('');
  const [showClaimModal, setShowClaimModal] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPaymentProof(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDeposit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    
    const amount = parseFloat(depositAmount);
    if (isNaN(amount) || amount <= 0) {
      setError('Please enter a valid amount');
      return;
    }

    if (!paymentProof) {
      setError('Please upload payment proof');
      return;
    }
    
    try {
      await deposit(amount, paymentProof);
      setSuccess('Deposit request submitted for approval');
      setDepositAmount('');
      setPaymentProof('');
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (err: any) {
      setError(err.message || 'Failed to deposit');
    }
  };
  
  const handleWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    
    const amount = parseFloat(withdrawAmount);
    if (isNaN(amount) || amount <= 0) {
      setError('Please enter a valid amount');
      return;
    }
    
    if (amount > balance) {
      setError('Insufficient funds');
      return;
    }
    
    try {
      await withdraw(amount);
      setSuccess('Withdrawal request submitted for approval');
      setWithdrawAmount('');
    } catch (err: any) {
      setError(err.message || 'Failed to withdraw');
    }
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'deposit':
        return <ArrowDownLeft className="h-5 w-5 text-green-400" />;
      case 'withdraw':
        return <ArrowUpRight className="h-5 w-5 text-red-400" />;
      case 'bet-win':
        return <DollarSign className="h-5 w-5 text-green-400" />;
      case 'bet-loss':
        return <DollarSign className="h-5 w-5 text-red-400" />;
      case 'commission':
        return <RefreshCw className="h-5 w-5 text-yellow-400" />;
      case 'bonus':
        return <Gift className="h-5 w-5 text-purple-400" />;
      default:
        return <FileText className="h-5 w-5 text-gray-400" />;
    }
  };

  const getTransactionStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'bg-green-900/50 text-green-400';
      case 'rejected':
        return 'bg-red-900/50 text-red-400';
      default:
        return 'bg-yellow-900/50 text-yellow-400';
    }
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'deposit':
        return (
          <form onSubmit={handleDeposit} className="space-y-4">
            <Input
              label="Deposit Amount"
              type="number"
              min="1"
              step="0.01"
              value={depositAmount}
              onChange={(e) => setDepositAmount(e.target.value)}
              placeholder="Enter amount to deposit"
              leftIcon={<DollarSign className="h-5 w-5 text-gray-400" />}
              fullWidth
            />
            
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-300">
                {/* TRC20 Address Box */}
<div className="text-center border border-gray-700 rounded-lg p-4 bg-gray-800">
  <p className="text-sm font-medium text-gray-300 mb-2">TRC20 Deposit Address</p>
  <div className="flex items-center justify-center space-x-2">
    <input
      id="trc20-address"
      type="text"
      readOnly
      value="TLBACu6vyaM2ZGg2kceWgD3mNh3iZNnvFU"
      className="bg-gray-900 text-white px-3 py-2 rounded-md text-sm w-full max-w-md"
    />
    <button
      type="button"
      onClick={() => {
        const input = document.getElementById('trc20-address') as HTMLInputElement;
        input.select();
        input.setSelectionRange(0, 99999);
        document.execCommand('copy');
        alert('Address copied: ' + input.value);
      }}
      className="px-3 py-2 text-sm font-medium bg-purple-600 hover:bg-purple-700 rounded-md text-white"
    >
      Copy
    </button>
  </div>
</div>

                Payment Proof
              </label>
              <div className="flex items-center space-x-2">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  ref={fileInputRef}
                  className="hidden"
                  id="payment-proof"
                />
                <Button
                  type="button"
                  variant="secondary"
                  onClick={() => document.getElementById('payment-proof')?.click()}
                  leftIcon={<Upload className="h-5 w-5" />}
                >
                  Upload Proof
                </Button>
                {paymentProof && (
                  <span className="text-green-400">✓ Proof uploaded</span>
                )}
              </div>
              <p className="text-sm text-gray-400">
                Please upload a screenshot or photo of your payment
              </p>
            </div>
            
            <Button
              type="submit"
              variant="success"
              isLoading={loading}
              fullWidth
            >
              Submit Deposit Request
            </Button>
          </form>
        );
      
      case 'withdraw':
        return (
          <form onSubmit={handleWithdraw} className="space-y-4">
            <Input
              label="Withdraw Amount"
              type="number"
              min="1"
              max={balance}
              step="0.01"
              value={withdrawAmount}
              onChange={(e) => setWithdrawAmount(e.target.value)}
              placeholder="Enter amount to withdraw"
              leftIcon={<DollarSign className="h-5 w-5 text-gray-400" />}
              fullWidth
            />
            
            <Button
              type="submit"
              variant="danger"
              isLoading={loading}
              fullWidth
            >
              Submit Withdrawal Request
            </Button>
          </form>
        );
      
      case 'history':
        return (
          <div className="space-y-4">
            {transactions.length > 0 ? (
              <div className="divide-y divide-gray-700">
                {transactions.map(transaction => (
                  <div key={transaction.id} className="py-4 flex items-center">
                    <div className="mr-4 p-2 rounded-full bg-gray-700">
                      {getTransactionIcon(transaction.type)}
                    </div>
                    <div className="flex-grow">
                      <div className="flex justify-between items-center">
                        <p className="font-medium text-white">{transaction.description}</p>
                        <p className={`font-bold ${transaction.amount > 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {transaction.amount > 0 ? '+' : ''}{transaction.amount.toFixed(2)} USD
                        </p>
                      </div>
                      <div className="flex justify-between items-center mt-1">
                        <p className="text-sm text-gray-400">
                          {new Date(transaction.timestamp).toLocaleString()}
                        </p>
                        <div className="flex items-center space-x-2">
                          <span className={`text-xs px-2 py-0.5 rounded-full ${getTransactionStatusColor(transaction.status)}`}>
                            {transaction.status}
                          </span>
                          <span className="text-xs bg-gray-700 px-2 py-0.5 rounded-full text-gray-300">
                            {transaction.type}
                          </span>
                        </div>
                      </div>
                      {transaction.adminNote && (
                        <p className="text-sm text-gray-400 mt-1">
                          Note: {transaction.adminNote}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-400">No transaction history yet.</p>
              </div>
            )}
          </div>
        );
      
      default:
        return null;
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white">Wallet</h1>
        <p className="text-gray-400">Manage your funds and transaction history</p>
      </div>

      {/* Balance Card */}
      <Card className="mb-8 overflow-hidden">
        <div className="bg-gradient-to-r from-purple-900 to-blue-900 p-8">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-300 mb-1">Current Balance</p>
              <h2 className="text-4xl font-bold text-white">${balance.toFixed(2)}</h2>
              {pendingBonus > 0 && (
                <p className="text-sm text-purple-300 mt-2">
                  Pending Bonus: ${pendingBonus.toFixed(2)}
                </p>
              )}
            </div>
            <div className="p-4 bg-white/10 rounded-full">
              <Wallet className="h-8 w-8 text-white" />
            </div>
          </div>
          
          <div className="mt-6 grid grid-cols-3 gap-2">
            <Button 
              variant="success" 
              leftIcon={<ArrowDownLeft className="h-4 w-4" />}
              onClick={() => setActiveTab('deposit')}
            >
              Deposit
            </Button>
            <Button 
              variant="danger" 
              leftIcon={<ArrowUpRight className="h-4 w-4" />}
              onClick={() => setActiveTab('withdraw')}
              disabled={balance <= 0}
            >
              Withdraw
            </Button>
            <Button 
              variant="secondary" 
              leftIcon={<Gift className="h-4 w-4" />}
              onClick={() => setShowClaimModal(true)}
            >
              Claim Reward
            </Button>
          </div>
        </div>
      </Card>

      {/* Tabs and Content */}
      <Card>
        {/* Tabs */}
        <div className="flex border-b border-gray-700">
          <button
            className={`flex-1 py-4 text-center font-medium ${
              activeTab === 'deposit' 
                ? 'text-purple-500 border-b-2 border-purple-500' 
                : 'text-gray-400 hover:text-gray-300'
            }`}
            onClick={() => setActiveTab('deposit')}
          >
            Deposit
          </button>
          <button
            className={`flex-1 py-4 text-center font-medium ${
              activeTab === 'withdraw' 
                ? 'text-purple-500 border-b-2 border-purple-500' 
                : 'text-gray-400 hover:text-gray-300'
            }`}
            onClick={() => setActiveTab('withdraw')}
          >
            Withdraw
          </button>
          <button
            className={`flex-1 py-4 text-center font-medium ${
              activeTab === 'history' 
                ? 'text-purple-500 border-b-2 border-purple-500' 
                : 'text-gray-400 hover:text-gray-300'
            }`}
            onClick={() => setActiveTab('history')}
          >
            History
          </button>
        </div>
        
        <CardBody>
          {/* Error and Success Messages */}
          {error && (
            <div className="mb-4 p-3 bg-red-900/50 border border-red-500 rounded-lg text-red-200 text-sm">
              {error}
            </div>
          )}
          
          {success && (
            <div className="mb-4 p-3 bg-green-900/50 border border-green-500 rounded-lg text-green-200 text-sm">
              {success}
            </div>
          )}
          
          {/* Tab Content */}
          {renderTabContent()}
        </CardBody>
      </Card>

      {/* Claim Reward Modal */}
      <ClaimRewardModal
        isOpen={showClaimModal}
        onClose={() => setShowClaimModal(false)}
      />
    </div>
  );
};

export default WalletPage;
