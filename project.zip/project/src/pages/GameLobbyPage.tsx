import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { useGames } from "../contexts/GamesContext";
import Button from "../components/ui/Button";
import Card, { CardHeader, CardBody } from "../components/ui/Card";
import { Clock, Plus, X, Gamepad2, Trophy, ArrowRight } from "lucide-react";

const GameLobbyPage: React.FC = () => {
  const { user } = useAuth();
  const { activeGames, completedGames, createGame, joinGame, cancelGame } =
    useGames();
  const [isCreating, setIsCreating] = useState(false);
  const [isJoining, setIsJoining] = useState<string | null>(null);
  const [isCancelling, setIsCancelling] = useState<string | null>(null);
  const navigate = useNavigate();

  // Filter games not created by the user and with status 'waiting'
  const availableGames = activeGames.filter(
    (game) => game.creatorId !== user?.id && game.status === "waiting"
  );

  // Games created by the user
  const myGames = activeGames.filter((game) => game.creatorId === user?.id);

  // Games the user has joined as an opponent
  const joinedGames = activeGames.filter(
    (game) => game.opponentId === user?.id
  );

  const handleCreateGame = async () => {
    setIsCreating(true);
    try {
      const game = await createGame();
      navigate(`/games/${game.id}`);
    } catch (error) {
      console.error("Error creating game:", error);
    } finally {
      setIsCreating(false);
    }
  };

  const handleJoinGame = async (gameId: string) => {
    setIsJoining(gameId);
    try {
      await joinGame(gameId);
      navigate(`/games/${gameId}`);
    } catch (error) {
      console.error("Error joining game:", error);
    } finally {
      setIsJoining(null);
    }
  };

  const handleCancelGame = async (gameId: string) => {
    setIsCancelling(gameId);
    try {
      await cancelGame(gameId);
    } catch (error) {
      console.error("Error cancelling game:", error);
    } finally {
      setIsCancelling(null);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-white">Game Lobby</h1>
        <Button
          variant="primary"
          leftIcon={<Plus className="h-5 w-5" />}
          onClick={handleCreateGame}
          isLoading={isCreating}
        >
          Create New Game
        </Button>
      </div>

      {/* Active Games Section */}
      <div className="mb-10">
        <h2 className="text-xl font-bold text-white mb-4 flex items-center">
          <Gamepad2 className="mr-2 h-5 w-5 text-purple-400" />
          Active Games
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* My Created Games */}
          {myGames.map((game) => (
            <Card key={game.id} className="border-l-4 border-l-blue-500">
              <CardBody>
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-white">
                      {game.status === "waiting"
                        ? "Waiting for Opponent"
                        : `vs. ${game.opponentUsername}`}
                    </h3>
                    <p className="text-gray-400 text-sm flex items-center mt-1">
                      <Clock className="mr-1 h-4 w-4" />
                      Created {new Date(game.createdAt).toLocaleString()}
                    </p>
                  </div>
                  <div className="bg-blue-900/50 text-blue-400 px-2 py-1 rounded text-xs font-semibold uppercase">
                    Your Game
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-white font-medium">Bet Amount:</span>
                    <span className="text-green-400 font-bold">
                      ${game.betAmount.toFixed(2)}
                    </span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-white font-medium">Status:</span>
                    <span
                      className={`text-sm font-semibold px-2 py-1 rounded ${
                        game.status === "waiting"
                          ? "bg-blue-900/50 text-blue-400"
                          : "bg-yellow-900/50 text-yellow-400"
                      }`}
                    >
                      {game.status === "waiting" ? "Waiting" : "In Progress"}
                    </span>
                  </div>

                  <div className="pt-2 flex justify-between">
                    <Button
                      variant="danger"
                      size="sm"
                      leftIcon={<X className="h-4 w-4" />}
                      onClick={() => handleCancelGame(game.id)}
                      isLoading={isCancelling === game.id}
                      disabled={game.status !== "waiting"}
                    >
                      Cancel
                    </Button>
                    <Link to={`/games/${game.id}`}>
                      <Button
                        variant="primary"
                        size="sm"
                        rightIcon={<ArrowRight className="h-4 w-4" />}
                      >
                        {game.status === "waiting" ? "View" : "Play"}
                      </Button>
                    </Link>
                  </div>
                </div>
              </CardBody>
            </Card>
          ))}

          {/* Joined Games */}
          {joinedGames.map((game) => (
            <Card key={game.id} className="border-l-4 border-l-purple-500">
              <CardBody>
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-white">
                      vs. {game.creatorUsername}
                    </h3>
                    <p className="text-gray-400 text-sm flex items-center mt-1">
                      <Clock className="mr-1 h-4 w-4" />
                      Joined {new Date(game.createdAt).toLocaleString()}
                    </p>
                  </div>
                  <div className="bg-purple-900/50 text-purple-400 px-2 py-1 rounded text-xs font-semibold uppercase">
                    Joined
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-white font-medium">Bet Amount:</span>
                    <span className="text-green-400 font-bold">
                      ${game.betAmount.toFixed(2)}
                    </span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-white font-medium">Status:</span>
                    <span className="bg-yellow-900/50 text-yellow-400 text-sm font-semibold px-2 py-1 rounded">
                      In Progress
                    </span>
                  </div>

                  <div className="pt-2 flex justify-end">
                    <Link to={`/games/${game.id}`}>
                      <Button
                        variant="primary"
                        size="sm"
                        rightIcon={<ArrowRight className="h-4 w-4" />}
                      >
                        Play
                      </Button>
                    </Link>
                  </div>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>

        {myGames.length === 0 && joinedGames.length === 0 && (
          <Card>
            <CardBody className="text-center py-8">
              <p className="text-gray-400 mb-4">
                You don't have any active games. Make Deposit Frist Play Games.
              </p>
              <Button
                variant="primary"
                leftIcon={<Plus className="h-5 w-5" />}
                onClick={handleCreateGame}
                isLoading={isCreating}
              >
                Create New Game
              </Button>
            </CardBody>
          </Card>
        )}
      </div>

      {/* Available Games Section */}
      <div className="mb-10">
        <h2 className="text-xl font-bold text-white mb-4 flex items-center">
          <Plus className="mr-2 h-5 w-5 text-purple-400" />
          Available Games
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {availableGames.map((game) => (
            <Card
              key={game.id}
              className="transform transition-all duration-200 hover:scale-105"
            >
              <CardBody>
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-white">
                      {game.creatorUsername}'s Game
                    </h3>
                    <p className="text-gray-400 text-sm flex items-center mt-1">
                      <Clock className="mr-1 h-4 w-4" />
                      Created {new Date(game.createdAt).toLocaleString()}
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-white font-medium">Bet Amount:</span>
                    <span className="text-green-400 font-bold">
                      ${game.betAmount.toFixed(2)}
                    </span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-white font-medium">
                      Potential Win:
                    </span>
                    <span className="text-green-400 font-bold">
                      ${(game.betAmount * 1.9).toFixed(2)}
                    </span>
                  </div>

                  <div className="pt-2 flex justify-center">
                    <Button
                      variant="primary"
                      fullWidth
                      onClick={() => handleJoinGame(game.id)}
                      isLoading={isJoining === game.id}
                    >
                      Join Game
                    </Button>
                  </div>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>

        {availableGames.length === 0 && (
          <Card>
            <CardBody className="text-center py-8">
              <p className="text-gray-400 mb-4">
                Make Deposit first PLay The Game.
              </p>
              <Button
                variant="primary"
                leftIcon={<Plus className="h-5 w-5" />}
                onClick={handleCreateGame}
                isLoading={isCreating}
              >
                Create New Game
              </Button>
            </CardBody>
          </Card>
        )}
      </div>

      {/* Game History Section */}
      <div>
        <h2 className="text-xl font-bold text-white mb-4 flex items-center">
          <Trophy className="mr-2 h-5 w-5 text-purple-400" />
          Game History
        </h2>

        {completedGames.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left border-b border-gray-700">
                  <th className="px-4 py-3 text-gray-300">Players</th>
                  <th className="px-4 py-3 text-gray-300">Date</th>
                  <th className="px-4 py-3 text-gray-300">Bet Amount</th>
                  <th className="px-4 py-3 text-gray-300">Result</th>
                  <th className="px-4 py-3 text-gray-300">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800">
                {completedGames.map((game) => {
                  const isCreator = game.creatorId === user?.id;
                  const opponent = isCreator
                    ? game.opponentUsername
                    : game.creatorUsername;
                  const hasWon = game.winnerId === user?.id;

                  return (
                    <tr key={game.id} className="hover:bg-gray-800/50">
                      <td className="px-4 py-3 text-white">
                        {isCreator ? "You" : game.creatorUsername} vs{" "}
                        {isCreator ? opponent : "You"}
                      </td>
                      <td className="px-4 py-3 text-gray-400">
                        {new Date(
                          game.completedAt || game.createdAt
                        ).toLocaleDateString()}
                      </td>
                      <td className="px-4 py-3 text-green-400 font-medium">
                        ${game.betAmount.toFixed(2)}
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className={`px-2 py-1 rounded text-xs font-medium ${
                            hasWon
                              ? "bg-green-900/50 text-green-400"
                              : "bg-red-900/50 text-red-400"
                          }`}
                        >
                          {hasWon ? "Won" : "Lost"}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <Link to={`/games/${game.id}`}>
                          <Button variant="secondary" size="sm">
                            Details
                          </Button>
                        </Link>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <Card>
            <CardBody className="text-center py-8">
              <p className="text-gray-400">No completed games yet.</p>
            </CardBody>
          </Card>
        )}
      </div>
    </div>
  );
};

export default GameLobbyPage;
