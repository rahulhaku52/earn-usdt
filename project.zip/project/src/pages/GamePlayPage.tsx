import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useGames } from '../contexts/GamesContext';
import { useWallet } from '../contexts/WalletContext';
import Button from '../components/ui/Button';
import Card, { CardHeader, CardBody, CardFooter } from '../components/ui/Card';
import { Clock, ArrowLeft, Dices, Trophy, AlertTriangle, Check, X, Spade, Diamond, Club, Heart } from 'lucide-react';

const GamePlayPage: React.FC = () => {
  const { gameId } = useParams<{ gameId: string }>();
  const { user } = useAuth();
  const { games, completeGame, updateGameState } = useGames();
  const { balance } = useWallet();
  const navigate = useNavigate();

  const [game, setGame] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [winnerSelected, setWinnerSelected] = useState<string | null>(null);
  const [isCompleting, setIsCompleting] = useState(false);
  
  // Dice game state
  const [diceValues, setDiceValues] = useState<number[]>([1, 1]);
  const [opponentDiceValues, setOpponentDiceValues] = useState<number[]>([1, 1]);
  const [isRolling, setIsRolling] = useState(false);
  const [hasRolled, setHasRolled] = useState(false);

  // Blackjack game state
  const [playerHand, setPlayerHand] = useState<string[]>([]);
  const [dealerHand, setDealerHand] = useState<string[]>([]);
  const [deck, setDeck] = useState<string[]>([]);
  const [playerScore, setPlayerScore] = useState(0);
  const [dealerScore, setDealerScore] = useState(0);
  const [isDealing, setIsDealing] = useState(false);
  const [playerStand, setPlayerStand] = useState(false);

  // Slots game state
  const [reels, setReels] = useState<string[][]>([
    ['🍒', '🍊', '🍇', '🍎', '💎', '7️⃣'],
    ['🍊', '🍇', '🍎', '💎', '7️⃣', '🍒'],
    ['🍇', '🍎', '💎', '7️⃣', '🍒', '🍊']
  ]);
  const [spinResult, setSpinResult] = useState<string[]>(['🍒', '🍊', '🍇']);
  const [isSpinning, setIsSpinning] = useState(false);

  // Roulette game state
  const [selectedNumber, setSelectedNumber] = useState<number | null>(null);
  const [winningNumber, setWinningNumber] = useState<number | null>(null);
  const [isSpinningRoulette, setIsSpinningRoulette] = useState(false);

  useEffect(() => {
    if (gameId) {
      const currentGame = games.find(g => g.id === gameId);
      if (currentGame) {
        setGame(currentGame);
        setError(null);
        
        // Initialize game-specific state
        if (currentGame.gameState) {
          switch (currentGame.type) {
            case 'blackjack':
              setPlayerHand(currentGame.gameState.playerHand);
              setDealerHand(currentGame.gameState.dealerHand);
              setPlayerScore(currentGame.gameState.playerScore);
              setDealerScore(currentGame.gameState.dealerScore);
              setPlayerStand(currentGame.gameState.playerStand);
              break;
            case 'slots':
              setSpinResult(currentGame.gameState.spinResult || spinResult);
              break;
            case 'roulette':
              setSelectedNumber(currentGame.gameState.selectedNumber);
              setWinningNumber(currentGame.gameState.winningNumber);
              break;
            default:
              break;
          }
        }
      } else {
        setError('Game not found');
      }
    }
    setLoading(false);
  }, [gameId, games]);

  // Blackjack functions
  const initializeDeck = () => {
    const suits = ['♠', '♥', '♦', '♣'];
    const values = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
    const newDeck = suits.flatMap(suit => values.map(value => `${value}${suit}`));
    return shuffleDeck(newDeck);
  };

  const shuffleDeck = (deck: string[]) => {
    const shuffled = [...deck];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  };

  const calculateScore = (hand: string[]) => {
    let score = 0;
    let aces = 0;

    for (const card of hand) {
      const value = card.slice(0, -1);
      if (value === 'A') {
        aces++;
        score += 11;
      } else if (['K', 'Q', 'J'].includes(value)) {
        score += 10;
      } else {
        score += parseInt(value);
      }
    }

    while (score > 21 && aces > 0) {
      score -= 10;
      aces--;
    }

    return score;
  };

  const dealBlackjack = async () => {
    setIsDealing(true);
    const newDeck = initializeDeck();
    const playerCards = [newDeck.pop()!, newDeck.pop()!];
    const dealerCards = [newDeck.pop()!];
    
    setDeck(newDeck);
    setPlayerHand(playerCards);
    setDealerHand(dealerCards);
    setPlayerScore(calculateScore(playerCards));
    setDealerScore(calculateScore(dealerCards));
    setPlayerStand(false);
    
    await updateGameState(game.id, {
      playerHand: playerCards,
      dealerHand: dealerCards,
      playerScore: calculateScore(playerCards),
      dealerScore: calculateScore(dealerCards),
      playerStand: false
    });
    
    setIsDealing(false);
  };

  const hit = async () => {
    if (playerStand || playerScore >= 21) return;
    
    const newDeck = [...deck];
    const newCard = newDeck.pop()!;
    const newHand = [...playerHand, newCard];
    const newScore = calculateScore(newHand);
    
    setDeck(newDeck);
    setPlayerHand(newHand);
    setPlayerScore(newScore);
    
    await updateGameState(game.id, {
      ...game.gameState,
      playerHand: newHand,
      playerScore: newScore
    });

    if (newScore > 21) {
      setWinnerSelected(isCreator ? game.opponentId : game.creatorId);
    }
  };

  const stand = async () => {
    setPlayerStand(true);
    let currentDealerHand = [...dealerHand];
    let currentDeck = [...deck];
    
    while (calculateScore(currentDealerHand) < 17) {
      const newCard = currentDeck.pop()!;
      currentDealerHand.push(newCard);
    }
    
    const finalDealerScore = calculateScore(currentDealerHand);
    setDealerHand(currentDealerHand);
    setDealerScore(finalDealerScore);
    
    await updateGameState(game.id, {
      ...game.gameState,
      dealerHand: currentDealerHand,
      dealerScore: finalDealerScore,
      playerStand: true
    });

    // Determine winner
    if (finalDealerScore > 21 || playerScore > finalDealerScore) {
      setWinnerSelected(user?.id || null);
    } else {
      setWinnerSelected(isCreator ? game.opponentId : game.creatorId);
    }
  };

  // Slots functions
  const spinSlots = async () => {
    setIsSpinning(true);
    
    // Simulate spinning animation
    const spinInterval = setInterval(() => {
      setSpinResult([
        reels[0][Math.floor(Math.random() * reels[0].length)],
        reels[1][Math.floor(Math.random() * reels[1].length)],
        reels[2][Math.floor(Math.random() * reels[2].length)]
      ]);
    }, 100);
    
    // Stop spinning after 3 seconds
    setTimeout(async () => {
      clearInterval(spinInterval);
      
      // Final result
      const finalResult = [
        reels[0][Math.floor(Math.random() * reels[0].length)],
        reels[1][Math.floor(Math.random() * reels[1].length)],
        reels[2][Math.floor(Math.random() * reels[2].length)]
      ];
      
      setSpinResult(finalResult);
      setIsSpinning(false);
      
      // Check for win (all symbols match)
      const isWin = finalResult.every(symbol => symbol === finalResult[0]);
      setWinnerSelected(isWin ? user?.id : (isCreator ? game.opponentId : game.creatorId));
      
      await updateGameState(game.id, {
        reels,
        spinResult: finalResult,
        hasSpun: true
      });
    }, 3000);
  };

  // Roulette functions
  const spinRoulette = async () => {
    if (!selectedNumber) return;
    
    setIsSpinningRoulette(true);
    
    // Simulate spinning animation
    const spinInterval = setInterval(() => {
      setWinningNumber(Math.floor(Math.random() * 37));
    }, 100);
    
    // Stop spinning after 3 seconds
    setTimeout(async () => {
      clearInterval(spinInterval);
      
      // Final result
      const finalNumber = Math.floor(Math.random() * 37);
      setWinningNumber(finalNumber);
      setIsSpinningRoulette(false);
      
      // Check for win
      const isWin = selectedNumber === finalNumber;
      setWinnerSelected(isWin ? user?.id : (isCreator ? game.opponentId : game.creatorId));
      
      await updateGameState(game.id, {
        selectedNumber,
        winningNumber: finalNumber,
        hasSpun: true
      });
    }, 3000);
  };

  // Dice game functions
  const rollDice = async () => {
    setIsRolling(true);
    
    // Simulate rolling animation
    const rollInterval = setInterval(() => {
      setDiceValues([
        Math.floor(Math.random() * 6) + 1,
        Math.floor(Math.random() * 6) + 1
      ]);
    }, 100);
    
    // Stop rolling after 2 seconds
    setTimeout(async () => {
      clearInterval(rollInterval);
      
      // Final dice values
      const finalDiceValues = [
        Math.floor(Math.random() * 6) + 1,
        Math.floor(Math.random() * 6) + 1
      ];
      setDiceValues(finalDiceValues);
      setHasRolled(true);
      setIsRolling(false);
      
      // Simulate opponent roll after 1 second
      setTimeout(async () => {
        const opponentValues = [
          Math.floor(Math.random() * 6) + 1,
          Math.floor(Math.random() * 6) + 1
        ];
        setOpponentDiceValues(opponentValues);
        
        // Determine winner based on dice total
        const playerTotal = finalDiceValues[0] + finalDiceValues[1];
        const opponentTotal = opponentValues[0] + opponentValues[1];
        
        if (playerTotal > opponentTotal) {
          setWinnerSelected(user?.id || null);
        } else {
          setWinnerSelected(isCreator ? game.opponentId : game.creatorId);
        }
        
        await updateGameState(game.id, {
          playerRoll: finalDiceValues,
          opponentRoll: opponentValues,
          hasRolled: true
        });
      }, 1000);
    }, 2000);
  };

  const handleCompleteGame = async () => {
    if (!winnerSelected) return;
    
    setIsCompleting(true);
    try {
      await completeGame(game.id, winnerSelected);
      // Game state will update through the context
    } catch (error) {
      console.error('Error completing game:', error);
    } finally {
      setIsCompleting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-purple-500"></div>
      </div>
    );
  }

  if (error || !game) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <Card>
          <CardBody className="text-center py-12">
            <AlertTriangle className="h-16 w-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-4">Game Not Found</h2>
            <p className="text-gray-400 mb-6">
              The game you're looking for doesn't exist or has been removed.
            </p>
            <Button 
              variant="primary" 
              leftIcon={<ArrowLeft className="h-5 w-5" />}
              onClick={() => navigate('/games')}
            >
              Back to Games
            </Button>
          </CardBody>
        </Card>
      </div>
    );
  }

  const isCreator = game.creatorId === user?.id;
  const opponent = isCreator ? game.opponentUsername : game.creatorUsername;
  const hasWon = game.status === 'completed' && game.winnerId === user?.id;
  const hasLost = game.status === 'completed' && game.winnerId !== user?.id && game.winnerId !== null;
  const isWaiting = game.status === 'waiting';
  const isActive = game.status === 'active';
  const isCompleted = game.status === 'completed';

  // Render dice face based on value
  const renderDiceFace = (value: number) => {
    const dotPositionClassMap: Record<number, string[]> = {
      1: ['justify-center items-center'],
      2: ['justify-start items-start', 'justify-end items-end'],
      3: ['justify-start items-start', 'justify-center items-center', 'justify-end items-end'],
      4: ['justify-start items-start', 'justify-end items-start', 'justify-start items-end', 'justify-end items-end'],
      5: ['justify-start items-start', 'justify-end items-start', 'justify-center items-center', 'justify-start items-end', 'justify-end items-end'],
      6: ['justify-start items-start', 'justify-end items-start', 'justify-start items-center', 'justify-end items-center', 'justify-start items-end', 'justify-end items-end']
    };

    return (
      <div className={`w-16 h-16 bg-white rounded-lg p-2 flex flex-wrap ${isRolling ? 'animate-bounce' : ''}`}>
        {dotPositionClassMap[value].map((positionClass, index) => (
          <div key={index} className={`w-full h-full flex ${positionClass}`}>
            <div className="w-3 h-3 bg-black rounded-full"></div>
          </div>
        ))}
      </div>
    );
  };

  // Render card with suit and value
  const renderCard = (card: string) => {
    const value = card.slice(0, -1);
    const suit = card.slice(-1);
    const isRed = suit === '♥' || suit === '♦';
    
    return (
      <div className="w-16 h-24 bg-white rounded-lg p-2 flex flex-col justify-between shadow-lg">
        <div className={`text-lg font-bold ${isRed ? 'text-red-600' : 'text-black'}`}>
          {value}
        </div>
        <div className={`text-2xl ${isRed ? 'text-red-600' : 'text-black'}`}>
          {suit}
        </div>
      </div>
    );
  };

  // Render roulette board
  const renderRouletteBoard = () => {
    const numbers = Array.from({ length: 37 }, (_, i) => i);
    
    return (
      <div className="grid grid-cols-6 gap-2 max-w-md mx-auto">
        <div className="col-span-1 bg-green-600 p-2 rounded text-center cursor-pointer hover:bg-green-500 transition-colors"
             onClick={() => setSelectedNumber(0)}>
          <span className="text-white font-bold">0</span>
        </div>
        {numbers.slice(1).map(num => (
          <div
            key={num}
            className={`p-2 rounded text-center cursor-pointer transition-colors ${
              selectedNumber === num
                ? 'bg-purple-600 text-white'
                : num % 2 === 0
                ? 'bg-red-600 hover:bg-red-500'
                : 'bg-black hover:bg-gray-800'
            }`}
            onClick={() => setSelectedNumber(num)}
          >
            <span className="text-white font-bold">{num}</span>
          </div>
        ))}
      </div>
    );
  };

  const renderGameContent = () => {
    switch (game.type) {
      case 'dice':
        return (
          <div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
              <div className="bg-gray-800 rounded-lg p-6 text-center">
                <h2 className="text-lg font-semibold text-white mb-4">You</h2>
                <div className="flex justify-center gap-4 mb-6">
                  {renderDiceFace(diceValues[0])}
                  {renderDiceFace(diceValues[1])}
                </div>
                <p className="text-xl font-bold text-white">
                  Total: {diceValues[0] + diceValues[1]}
                </p>
              </div>
              
              <div className="bg-gray-800 rounded-lg p-6 text-center">
                <h2 className="text-lg font-semibold text-white mb-4">{opponent}</h2>
                <div className="flex justify-center gap-4 mb-6">
                  {renderDiceFace(opponentDiceValues[0])}
                  {renderDiceFace(opponentDiceValues[1])}
                </div>
                <p className="text-xl font-bold text-white">
                  Total: {opponentDiceValues[0] + opponentDiceValues[1]}
                </p>
              </div>
            </div>
            
            <div className="text-center">
              {!hasRolled ? (
                <Button 
                  variant="primary" 
                  size="lg" 
                  leftIcon={<Dices className="h-5 w-5" />}
                  onClick={rollDice}
                  isLoading={isRolling}
                  disabled={isRolling}
                >
                  Roll Dice
                </Button>
              ) : (
                <div>
                  <div className={`inline-block px-4 py-2 rounded-lg mb-6 ${
                    winnerSelected === user?.id 
                      ? 'bg-green-900/50 text-green-400 border border-green-500' 
                      : 'bg-red-900/50 text-red-400 border border-red-500'
                  }`}>
                    <div className="flex items-center">
                      {winnerSelected === user?.id ? (
                        <Check className="h-5 w-5 mr-2" />
                      ) : (
                        <X className="h-5 w-5 mr-2" />
                      )}
                      <span className="font-bold">
                        {winnerSelected === user?.id ? 'You Win!' : 'You Lose!'}
                      </span>
                    </div>
                  </div>
                  
                  <Button 
                    variant={winnerSelected === user?.id ? 'success' : 'danger'}
                    size="lg" 
                    rightIcon={<Trophy className="h-5 w-5" />}
                    onClick={handleCompleteGame}
                    isLoading={isCompleting}
                  >
                    Claim {winnerSelected === user?.id ? 'Winnings' : 'Result'}
                  </Button>
                </div>
              )}
            </div>
          </div>
        );
      
      case 'blackjack':
        return (
          <div>
            <div className="grid grid-cols-1 gap-8 mb-8">
              <div className="bg-gray-800 rounded-lg p-6">
                <h2 className="text-lg font-semibold text-white mb-4">Dealer's Hand</h2>
                <div className="flex gap-4 mb-4">
                  {dealerHand.map((card, index) => (
                    <div key={index} className="animate-fade-in">
                      {renderCard(card)}
                    </div>
                  ))}
                </div>
                <p className="text-xl font-bold text-white">
                  Score: {playerStand ? dealerScore : '?'}
                </p>
              </div>
              
              <div className="bg-gray-800 rounded-lg p-6">
                <h2 className="text-lg font-semibold text-white mb-4">Your Hand</h2>
                <div className="flex gap-4 mb-4">
                  {playerHand.map((card, index) => (
                    <div key={index} className="animate-fade-in">
                      {renderCard(card)}
                    </div>
                  ))}
                </div>
                <p className="text-xl font-bold text-white">
                  Score: {playerScore}
                </p>
              </div>
            </div>
            
            <div className="text-center space-y-4">
              {playerHand.length === 0 ? (
                <Button 
                  variant="primary" 
                  size="lg"
                  onClick={dealBlackjack}
                  isLoading={isDealing}
                  disabled={isDealing}
                >
                  Deal Cards
                </Button>
              ) : !playerStand && playerScore < 21 ? (
                <div className="space-x-4">
                  <Button 
                    variant="primary"
                    size="lg"
                    onClick={hit}
                    disabled={isDealing}
                  >
                    Hit
                  </Button>
                  <Button 
                    variant="secondary"
                    size="lg"
                    onClick={stand}
                    disabled={isDealing}
                  >
                    Stand
                  </Button>
                </div>
              ) : winnerSelected && (
                <div>
                  <div className={`inline-block px-4 py-2 rounded-lg mb-6 ${
                    winnerSelected === user?.id 
                      ? 'bg-green-900/50 text-green-400 border border-green-500' 
                      : 'bg-red-900/50 text-red-400 border border-red-500'
                  }`}>
                    <div className="flex items-center">
                      {winnerSelected === user?.id ? (
                        <Check className="h-5 w-5 mr-2" />
                      ) : (
                        <X className="h-5 w-5 mr-2" />
                      )}
                      <span className="font-bold">
                        {winnerSelected === user?.id ? 'You Win!' : 'You Lose!'}
                      </span>
                    </div>
                  </div>
                  
                  <Button 
                    variant={winnerSelected === user?.id ? 'success' : 'danger'}
                    size="lg" 
                    rightIcon={<Trophy className="h-5 w-5" />}
                    onClick={handleCompleteGame}
                    isLoading={isCompleting}
                  >
                    Claim {winnerSelected === user?.id ? 'Winnings' : 'Result'}
                  </Button>
                </div>
              )}
            </div>
          </div>
        );
      
      case 'slots':
        return (
          <div className="text-center">
            <div className="bg-gray-800 rounded-lg p-8 mb-8">
              <div className="flex justify-center gap-4 mb-8">
                {spinResult.map((symbol, index) => (
                  <div
                    key={index}
                    className={`w-24 h-24 bg-gray-700 rounded-lg flex items-center justify-center text-4xl ${
                      isSpinning ? 'animate-spin' : ''
                    }`}
                  >
                    {symbol}
                  </div>
                ))}
              </div>
              
              {!winnerSelected ? (
                <Button 
                  variant="primary" 
                  size="lg"
                  onClick={spinSlots}
                  isLoading={isSpinning}
                  disabled={isSpinning}
                >
                  Spin
                </Button>
              ) : (
                <div>
                  <div className={`inline-block px-4 py-2 rounded-lg mb-6 ${
                    winnerSelected === user?.id 
                      ? 'bg-green-900/50 text-green-400 border border-green-500' 
                      : 'bg-red-900/50 text-red-400 border border-red-500'
                  }`}>
                    <div className="flex items-center">
                      {winnerSelected === user?.id ? (
                        <Check className="h-5 w-5 mr-2" />
                      ) : (
                        <X className="h-5 w-5 mr-2" />
                      )}
                      <span className="font-bold">
                        {winnerSelected === user?.id ? 'You Win!' : 'You Lose!'}
                      </span>
                    </div>
                  </div>
                  
                  <Button 
                    variant={winnerSelected === user?.id ? 'success' : 'danger'}
                    size="lg" 
                    rightIcon={<Trophy className="h-5 w-5" />}
                    onClick={handleCompleteGame}
                    isLoading={isCompleting}
                  >
                    Claim {winnerSelected === user?.id ? 'Winnings' : 'Result'}
                  </Button>
                </div>
              )}
            </div>
            
            <div className="text-sm text-gray-400">
              Match all three symbols to win!
            </div>
          </div>
        );
      
      case 'roulette':
        return (
          <div className="text-center">
            <div className="bg-gray-800 rounded-lg p-8 mb-8">
              {winningNumber !== null && (
                <div className="mb-8">
                  <div className={`text-6xl font-bold mb-4 ${
                    isSpinningRoulette ? 'animate-pulse' : ''
                  }`}>
                    {winningNumber}
                  </div>
                  <div className="text-gray-400">
                    Winning Number
                  </div>
                </div>
              )}
              
              {renderRouletteBoard()}
              
              <div className="mt-8">
                {selectedNumber !== null && !winnerSelected ? (
                  <Button 
                    variant="primary" 
                    size="lg"
                    onClick={spinRoulette}
                    isLoading={isSpinningRoulette}
                    disabled={isSpinningRoulette}
                  >
                    Spin Roulette
                  </Button>
                ) : winnerSelected ? (
                  <div>
                    <div className={`inline-block px-4 py-2 rounded-lg mb-6 ${
                      winnerSelected === user?.id 
                        ? 'bg-green-900/50 text-green-400 border border-green-500' 
                        : 'bg-red-900/50 text-red-400 border border-red-500'
                    }`}>
                      <div className="flex items-center">
                        {winnerSelected === user?.id ? (
                          <Check className="h-5 w-5 mr-2" />
                        ) : (
                          <X className="h-5 w-5 mr-2" />
                        )}
                        <span className="font-bold">
                          {winnerSelected === user?.id ? 'You Win!' : 'You Lose!'}
                        </span>
                      </div>
                    </div>
                    
                    <Button 
                      variant={winnerSelected === user?.id ? 'success' : 'danger'}
                      size="lg" 
                      rightIcon={<Trophy className="h-5 w-5" />}
                      onClick={handleCompleteGame}
                      isLoading={isCompleting}
                    >
                      Claim {winnerSelected === user?.id ? 'Winnings' : 'Result'}
                    </Button>
                  </div>
                ) : (
                  <div className="text-gray-400">
                    Select a number to place your bet
                  </div>
                )}
              </div>
            </div>
          </div>
        );
      
      default:
        return null;
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6 flex justify-between items-center">
        <Button 
          variant="secondary" 
          size="sm" 
          leftIcon={<ArrowLeft className="h-4 w-4" />}
          onClick={() => navigate('/games')}
        >
          Back to Games
        </Button>
        <div className="text-sm text-gray-400 flex items-center">
          <span className="font-semibold mr-2">Your Balance:</span> 
          <span className="text-green-400 font-bold">${balance.toFixed(2)}</span>
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-white flex items-center">
              {game.type === 'dice' && <Dices className="mr-2 h-6 w-6 text-purple-500" />}
              {game.type === 'blackjack' && <Spade className="mr-2 h-6 w-6 text-purple-500" />}
              {game.type === 'slots' && <Diamond className="mr-2 h-6 w-6 text-purple-500" />}
              {game.type === 'roulette' && <Club className="mr-2 h-6 w-6 text-purple-500" />}
              {isWaiting 
                ? 'Waiting for Opponent' 
                : isActive 
                  ? `Game vs ${opponent}` 
                  : isCompleted && hasWon 
                    ? 'You Won!' 
                    : 'Game Results'}
            </h1>
            <div className={`px-3 py-1.5 rounded-full text-sm font-semibold ${
              isWaiting ? 'bg-blue-900/50 text-blue-400' : 
              isActive ? 'bg-yellow-900/50 text-yellow-400' :
              hasWon ? 'bg-green-900/50 text-green-400' :
              'bg-red-900/50 text-red-400'
            }`}>
              {isWaiting ? 'Waiting' : isActive ? 'Active' : hasWon ? 'Won' : 'Lost'}
            </div>
          </div>
        </CardHeader>
        
        <CardBody className="py-8">
          {isWaiting ? (
            <div className="text-center py-8">
              <div className="animate-pulse mb-6">
                <Clock className="h-16 w-16 text-blue-400 mx-auto" />
              </div>
              <h2 className="text-xl font-bold text-white mb-4">Waiting for an Opponent</h2>
              <p className="text-gray-400 mb-6 max-w-md mx-auto">
                Your game has been created and is waiting for someone to join. You'll be notified when someone joins.
              </p>
              <div className="flex justify-center">
                <Button 
                  variant="secondary" 
                  onClick={() => navigate('/games')}
                >
                  Back to Lobby
                </Button>
              </div>
            </div>
          ) : isActive ? (
            renderGameContent()
          ) : (
            <div className="text-center">
              <div className={`inline-block p-6 rounded-full mb-6 ${
                hasWon ? 'bg-green-900/20 text-green-400' : 'bg-red-900/20 text-red-400'
              }`}>
                {hasWon ? (
                  <Trophy className="h-16 w-16" />
                ) : (
                  <X className="h-16 w-16" />
                )}
              </div>
              
              <h2 className="text-2xl font-bold text-white mb-2">
                {hasWon ? 'Congratulations! You Won!' : 'You Lost This Game'}
              </h2>
              
              {hasWon ? (
                <p className="text-green-400 text-lg font-semibold mb-8">
                  +${(game.betAmount * 1.9).toFixed(2)} has been added to your wallet
                </p>
              ) : (
                <p className="text-red-400 text-lg font-semibold mb-8">
                  -${game.betAmount.toFixed(2)} has been deducted from your wallet
                </p>
              )}
              
              <div className="flex justify-center gap-4">
                <Button 
                  variant="secondary" 
                  leftIcon={<ArrowLeft className="h-5 w-5" />}
                  onClick={() => navigate('/games')}
                >
                  Back to Games
                </Button>
                
                <Button 
                  variant="primary" 
                  leftIcon={<Dices className="h-5 w-5" />}
                  onClick={() => navigate('/games')}
                >
                  Play Again
                </Button>
              </div>
            </div>
          )}
        </CardBody>
        
        <CardFooter className="bg-gray-800/50">
          <div className="w-full flex justify-between items-center">
            <div>
              <p className="text-sm text-gray-400">
                Game ID: <span className="text-gray-300">{game.id.substring(0, 8)}</span>
              </p>
              <p className="text-sm text-gray-400">
                Created: <span className="text-gray-300">{new Date(game.createdAt).toLocaleString()}</span>
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-400">
                Bet Amount: <span className="text-green-400 font-bold">${game.betAmount.toFixed(2)}</span>
              </p>
              <p className="text-sm text-gray-400">
                Commission: <span className="text-gray-300">${(game.betAmount * 0.1).toFixed(2)}</span>
              </p>
            </div>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
};

export default GamePlayPage;