export interface Transaction {
  id: string;
  userId: string;
  type: string; // 'deposit', 'withdraw', 'bet-win', 'bet-loss', 'commission'
  amount: number;
  description: string;
  timestamp: string;
  status: 'pending' | 'approved' | 'rejected';
  adminNote?: string;
}

export interface TransactionRequest {
  id: string;
  userId: string;
  type: 'deposit' | 'withdraw';
  amount: number;
  status: 'pending' | 'approved' | 'rejected';
  timestamp: string;
  paymentProof?: string;
  adminNote?: string;
}