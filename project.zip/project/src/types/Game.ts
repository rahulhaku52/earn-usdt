export type GameType = 'dice' | 'blackjack' | 'slots' | 'roulette';
export type GameStatus = 'waiting' | 'active' | 'completed';
export type OpponentType = 'human' | 'ai';

export interface Game {
  id: string;
  type: GameType;
  creatorId: string;
  creatorUsername: string;
  opponentId: string | null;
  opponentUsername: string | null;
  opponentType: OpponentType;
  status: GameStatus;
  betAmount: number;
  winnerId: string | null;
  createdAt: string;
  completedAt: string | null;
  gameState?: any; // Stores game-specific state
}

export interface DiceGameState {
  playerRoll: number[];
  opponentRoll: number[];
  hasRolled: boolean;
}

export interface BlackjackGameState {
  playerHand: string[];
  dealerHand: string[];
  playerScore: number;
  dealerScore: number;
  playerStand: boolean;
}

export interface RouletteGameState {
  selectedNumber: number | null;
  winningNumber: number | null;
  hasSpun: boolean;
}

export interface SlotsGameState {
  reels: string[][];
  spinResult: string[] | null;
  hasSpun: boolean;
}