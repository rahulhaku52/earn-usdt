import React, { createContext, useState, useContext, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { Game, GameStatus, GameType, OpponentType } from '../types/Game';
import { useAuth } from './AuthContext';
import { useWallet } from './WalletContext';

type GamesContextType = {
  games: Game[];
  activeGames: Game[];
  completedGames: Game[];
  createGame: (type: GameType) => Promise<Game>;
  joinGame: (gameId: string) => Promise<void>;
  playAgainstAI: (type: GameType) => Promise<Game>;
  cancelGame: (gameId: string) => Promise<void>;
  completeGame: (gameId: string, winnerId: string) => Promise<void>;
  updateGameState: (gameId: string, gameState: any) => Promise<void>;
  loading: boolean;
  currentGame: Game | null;
  showDepositModal: boolean;
  setShowDepositModal: (show: boolean) => void;
};

const GamesContext = createContext<GamesContextType | undefined>(undefined);

const BET_AMOUNT = 2; // $2 per player
const AI_NAMES = ['AlphaBot', 'BetMaster', 'CryptoAI', 'DeepPlayer', 'EliteBot'];

export const GamesProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const { balance, hasDeposited } = useWallet();
  const [games, setGames] = useState<Game[]>([]);
  const [currentGame, setCurrentGame] = useState<Game | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [showDepositModal, setShowDepositModal] = useState<boolean>(false);

  useEffect(() => {
    const storedGames = localStorage.getItem('games');
    if (storedGames) {
      setGames(JSON.parse(storedGames));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('games', JSON.stringify(games));
  }, [games]);

  const activeGames = games.filter(game => game.status === 'waiting' || game.status === 'active');
  const completedGames = games.filter(game => game.status === 'completed');

  const checkRequirements = () => {
    if (!hasDeposited) {
      setShowDepositModal(true);
      throw new Error('Please make a deposit first');
    }
    if (balance < BET_AMOUNT) {
      throw new Error('Insufficient balance');
    }
  };

  const createGame = async (type: GameType) => {
    if (!user) throw new Error('User must be logged in');
    
    checkRequirements();
    
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const newGame: Game = {
        id: uuidv4(),
        type,
        creatorId: user.id,
        creatorUsername: user.username,
        opponentId: null,
        opponentUsername: null,
        opponentType: 'human',
        status: 'waiting',
        betAmount: BET_AMOUNT,
        winnerId: null,
        createdAt: new Date().toISOString(),
        completedAt: null,
        gameState: initializeGameState(type)
      };
      
      setGames(prev => [newGame, ...prev]);
      setCurrentGame(newGame);
      return newGame;
    } finally {
      setLoading(false);
    }
  };

  const playAgainstAI = async (type: GameType) => {
    if (!user) throw new Error('User must be logged in');
    
    checkRequirements();
    
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const aiName = AI_NAMES[Math.floor(Math.random() * AI_NAMES.length)];
      const aiId = `ai_${uuidv4()}`;
      
      const newGame: Game = {
        id: uuidv4(),
        type,
        creatorId: user.id,
        creatorUsername: user.username,
        opponentId: aiId,
        opponentUsername: aiName,
        opponentType: 'ai',
        status: 'active',
        betAmount: BET_AMOUNT,
        winnerId: null,
        createdAt: new Date().toISOString(),
        completedAt: null,
        gameState: initializeGameState(type)
      };
      
      setGames(prev => [newGame, ...prev]);
      setCurrentGame(newGame);
      return newGame;
    } finally {
      setLoading(false);
    }
  };
  
  const joinGame = async (gameId: string) => {
    if (!user) throw new Error('User must be logged in');
    
    checkRequirements();
    
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setGames(prev => prev.map(game => {
        if (game.id === gameId) {
          const updatedGame = {
            ...game,
            opponentId: user.id,
            opponentUsername: user.username,
            opponentType: 'human',
            status: 'active' as GameStatus
          };
          setCurrentGame(updatedGame);
          return updatedGame;
        }
        return game;
      }));
    } finally {
      setLoading(false);
    }
  };
  
  const cancelGame = async (gameId: string) => {
    if (!user) throw new Error('User must be logged in');
    
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setGames(prev => prev.filter(game => game.id !== gameId));
      if (currentGame?.id === gameId) {
        setCurrentGame(null);
      }
    } finally {
      setLoading(false);
    }
  };

  const updateGameState = async (gameId: string, gameState: any) => {
    setGames(prev => prev.map(game => {
      if (game.id === gameId) {
        return { ...game, gameState };
      }
      return game;
    }));
  };
  
  const completeGame = async (gameId: string, winnerId: string) => {
    if (!user) throw new Error('User must be logged in');
    
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 800));
      
      const game = games.find(g => g.id === gameId);
      if (!game) throw new Error('Game not found');
      if (game.status === 'completed') throw new Error('Game already completed');
      
      const isWinner = user.id === winnerId;
      await processBet(BET_AMOUNT, isWinner);
      
      setGames(prev => prev.map(g => {
        if (g.id === gameId) {
          const updatedGame = {
            ...g,
            status: 'completed' as GameStatus,
            winnerId,
            completedAt: new Date().toISOString()
          };
          return updatedGame;
        }
        return g;
      }));
      
      setCurrentGame(null);
    } finally {
      setLoading(false);
    }
  };

  const initializeGameState = (type: GameType) => {
    switch (type) {
      case 'dice':
        return {
          playerRoll: [1, 1],
          opponentRoll: [1, 1],
          hasRolled: false
        };
      case 'blackjack':
        return {
          playerHand: [],
          dealerHand: [],
          playerScore: 0,
          dealerScore: 0,
          playerStand: false
        };
      case 'roulette':
        return {
          selectedNumber: null,
          winningNumber: null,
          hasSpun: false
        };
      case 'slots':
        return {
          reels: [
            ['🍒', '🍊', '🍇', '🍎', '💎', '7️⃣'],
            ['🍊', '🍇', '🍎', '💎', '7️⃣', '🍒'],
            ['🍇', '🍎', '💎', '7️⃣', '🍒', '🍊']
          ],
          spinResult: null,
          hasSpun: false
        };
      default:
        return {};
    }
  };

  return (
    <GamesContext.Provider
      value={{
        games,
        activeGames,
        completedGames,
        createGame,
        joinGame,
        playAgainstAI,
        cancelGame,
        completeGame,
        updateGameState,
        loading,
        currentGame,
        showDepositModal,
        setShowDepositModal
      }}
    >
      {children}
    </GamesContext.Provider>
  );
};

export const useGames = () => {
  const context = useContext(GamesContext);
  if (context === undefined) {
    throw new Error('useGames must be used within a GamesProvider');
  }
  return context;
};