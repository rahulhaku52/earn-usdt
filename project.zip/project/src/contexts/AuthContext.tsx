import React, { createContext, useState, useContext, useEffect } from 'react';
import { User } from '../types/User';

type AuthContextType = {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  signup: (email: string, password: string, username: string) => Promise<void>;
  adminLogin: (username: string, password: string) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
  isAdmin: boolean;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock user data for demo purposes
const MOCK_USERS: User[] = [
  {
    id: '1',
    email: 'demo@example.com',
    username: 'demo_user',
    createdAt: new Date().toISOString(),
  }
];

// Admin credentials - ensure these match what you're using to log in
const ADMIN_CREDENTIALS = {
  username: 'admin',
  password: 'admin123'
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check if user is stored in localStorage
    const storedUser = localStorage.getItem('user');
    const storedIsAdmin = localStorage.getItem('isAdmin');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    if (storedIsAdmin) {
      setIsAdmin(JSON.parse(storedIsAdmin));
    }
    setLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    setLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // In a real app, validate credentials against a backend
      const foundUser = MOCK_USERS.find(u => u.email === email);
      
      if (!foundUser) {
        throw new Error('Invalid credentials');
      }
      
      setUser(foundUser);
      localStorage.setItem('user', JSON.stringify(foundUser));
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const adminLogin = async (username: string, password: string) => {
    setLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Convert credentials to lowercase for case-insensitive comparison
      const normalizedInputUsername = username.toLowerCase();
      const normalizedInputPassword = password;
      const normalizedStoredUsername = ADMIN_CREDENTIALS.username.toLowerCase();
      
      console.log('Attempting admin login with:', {
        inputUsername: normalizedInputUsername,
        storedUsername: normalizedStoredUsername,
        passwordsMatch: normalizedInputPassword === ADMIN_CREDENTIALS.password
      });

      if (
        normalizedInputUsername !== normalizedStoredUsername || 
        normalizedInputPassword !== ADMIN_CREDENTIALS.password
      ) {
        throw new Error('Invalid admin credentials');
      }

      setIsAdmin(true);
      localStorage.setItem('isAdmin', 'true');
    } catch (error) {
      console.error('Admin login error:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };
  
  const signup = async (email: string, password: string, username: string) => {
    setLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Check if email is already taken
      if (MOCK_USERS.some(u => u.email === email)) {
        throw new Error('Email is already taken');
      }
      
      // Create new user
      const newUser: User = {
        id: Math.random().toString(36).substring(2, 9),
        email,
        username,
        createdAt: new Date().toISOString(),
      };
      
      // In a real app, save to backend
      MOCK_USERS.push(newUser);
      
      setUser(newUser);
      localStorage.setItem('user', JSON.stringify(newUser));
    } catch (error) {
      console.error('Signup error:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };
  
  const logout = () => {
    setUser(null);
    setIsAdmin(false);
    localStorage.removeItem('user');
    localStorage.removeItem('isAdmin');
  };

  return (
    <AuthContext.Provider 
      value={{ 
        user, 
        loading, 
        login, 
        signup,
        adminLogin,
        logout,
        isAuthenticated: !!user,
        isAdmin
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};