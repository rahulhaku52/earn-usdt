import React, { createContext, useState, useContext, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { useAuth } from './AuthContext';
import { Transaction, TransactionRequest } from '../types/Transaction';

type WalletContextType = {
  balance: number;
  transactions: Transaction[];
  transactionRequests: TransactionRequest[];
  deposit: (amount: number, paymentProof: string) => Promise<void>;
  withdraw: (amount: number) => Promise<void>;
  processBet: (amount: number, isWin: boolean) => Promise<void>;
  approveTransaction: (transactionId: string, adminNote?: string) => Promise<void>;
  rejectTransaction: (transactionId: string, adminNote?: string) => Promise<void>;
  claimReward: (promoCode: string) => Promise<void>;
  loading: boolean;
  hasUnlockedBonus: boolean;
  hasDeposited: boolean;
  bonusAmount: number;
};

const WalletContext = createContext<WalletContextType | undefined>(undefined);

const PLATFORM_WALLET = 'UQB3VDpke1ydI1p5O2FD3blJiOMTCIW3obD0u1GbGdD0nqBQ';
const COMMISSION_RATE = 0.05; // 5% commission
const PROMO_CODE = 'Super50';
const BONUS_AMOUNT = 50;
const MIN_DEPOSIT = 10;

export const WalletProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [balance, setBalance] = useState<number>(0);
  const [bonusAmount, setBonusAmount] = useState<number>(0);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [transactionRequests, setTransactionRequests] = useState<TransactionRequest[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [hasUnlockedBonus, setHasUnlockedBonus] = useState<boolean>(false);
  const [hasDeposited, setHasDeposited] = useState<boolean>(false);

  useEffect(() => {
    if (user) {
      const storedBalance = localStorage.getItem(`balance_${user.id}`);
      const storedBonusAmount = localStorage.getItem(`bonusAmount_${user.id}`);
      const storedTransactions = localStorage.getItem(`transactions_${user.id}`);
      const storedRequests = localStorage.getItem(`requests_${user.id}`);
      const storedHasUnlockedBonus = localStorage.getItem(`hasUnlockedBonus_${user.id}`);
      const storedHasDeposited = localStorage.getItem(`hasDeposited_${user.id}`);
      
      if (storedBalance) setBalance(parseFloat(storedBalance));
      if (storedBonusAmount) setBonusAmount(parseFloat(storedBonusAmount));
      if (storedTransactions) setTransactions(JSON.parse(storedTransactions));
      if (storedRequests) setTransactionRequests(JSON.parse(storedRequests));
      if (storedHasUnlockedBonus) setHasUnlockedBonus(JSON.parse(storedHasUnlockedBonus));
      if (storedHasDeposited) setHasDeposited(JSON.parse(storedHasDeposited));
    } else {
      setBalance(0);
      setBonusAmount(0);
      setTransactions([]);
      setTransactionRequests([]);
      setHasUnlockedBonus(false);
      setHasDeposited(false);
    }
  }, [user]);

  useEffect(() => {
    if (user) {
      localStorage.setItem(`balance_${user.id}`, balance.toString());
      localStorage.setItem(`bonusAmount_${user.id}`, bonusAmount.toString());
      localStorage.setItem(`transactions_${user.id}`, JSON.stringify(transactions));
      localStorage.setItem(`requests_${user.id}`, JSON.stringify(transactionRequests));
      localStorage.setItem(`hasUnlockedBonus_${user.id}`, JSON.stringify(hasUnlockedBonus));
      localStorage.setItem(`hasDeposited_${user.id}`, JSON.stringify(hasDeposited));
    }
  }, [user, balance, bonusAmount, transactions, transactionRequests, hasUnlockedBonus, hasDeposited]);

  const addTransaction = (type: string, amount: number, description: string, status: 'pending' | 'approved' | 'rejected' = 'approved') => {
    const newTransaction: Transaction = {
      id: uuidv4(),
      userId: user?.id || 'guest',
      type,
      amount,
      description,
      timestamp: new Date().toISOString(),
      status
    };
    
    setTransactions(prev => [newTransaction, ...prev]);
    return newTransaction;
  };

  const claimReward = async (promoCode: string) => {
    if (!user) throw new Error('User must be logged in');
    if (hasUnlockedBonus) throw new Error('You have already claimed a bonus');
    if (promoCode !== PROMO_CODE) throw new Error('Invalid promo code');
    
    setLoading(true);
    try {
      setBalance(prev => prev + BONUS_AMOUNT);
      setHasUnlockedBonus(true);
      addTransaction('bonus', BONUS_AMOUNT, 'Bonus reward claimed', 'approved');
    } catch (error) {
      console.error('Claim reward error:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const deposit = async (amount: number, paymentProof: string) => {
    if (amount <= 0) throw new Error('Amount must be positive');
    if (!user) throw new Error('User must be logged in');
    
    setLoading(true);
    try {
      const request: TransactionRequest = {
        id: uuidv4(),
        userId: user.id,
        type: 'deposit',
        amount,
        status: 'pending',
        timestamp: new Date().toISOString(),
        paymentProof
      };
      
      setTransactionRequests(prev => [request, ...prev]);
      addTransaction('deposit', amount, 'Deposit request pending approval', 'pending');
    } catch (error) {
      console.error('Deposit error:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };
  
  const withdraw = async (amount: number) => {
    if (amount <= 0) throw new Error('Amount must be positive');
    if (!user) throw new Error('User must be logged in');
    if (balance < amount) throw new Error('Insufficient funds');
    if (!hasDeposited) throw new Error('Please make a deposit first');
    
    setLoading(true);
    try {
      const request: TransactionRequest = {
        id: uuidv4(),
        userId: user.id,
        type: 'withdraw',
        amount,
        status: 'pending',
        timestamp: new Date().toISOString()
      };
      
      setTransactionRequests(prev => [request, ...prev]);
      addTransaction('withdraw', -amount, 'Withdrawal request pending approval', 'pending');
    } catch (error) {
      console.error('Withdraw error:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const approveTransaction = async (transactionId: string, adminNote?: string) => {
    setLoading(true);
    try {
      const request = transactionRequests.find(r => r.id === transactionId);
      if (!request) throw new Error('Transaction request not found');

      if (request.type === 'deposit') {
        setBalance(prev => prev + request.amount);
        setHasDeposited(true);
        addTransaction('deposit', request.amount, `Deposit approved${adminNote ? `: ${adminNote}` : ''}`, 'approved');
      } else {
        setBalance(prev => prev - request.amount);
        addTransaction('withdraw', -request.amount, `Withdrawal approved${adminNote ? `: ${adminNote}` : ''}`, 'approved');
      }

      setTransactionRequests(prev =>
        prev.map(r =>
          r.id === transactionId
            ? { ...r, status: 'approved', adminNote }
            : r
        )
      );
    } catch (error) {
      console.error('Approve transaction error:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const rejectTransaction = async (transactionId: string, adminNote?: string) => {
    setLoading(true);
    try {
      const request = transactionRequests.find(r => r.id === transactionId);
      if (!request) throw new Error('Transaction request not found');

      setTransactionRequests(prev =>
        prev.map(r =>
          r.id === transactionId
            ? { ...r, status: 'rejected', adminNote }
            : r
        )
      );

      addTransaction(
        request.type,
        request.type === 'deposit' ? request.amount : -request.amount,
        `${request.type === 'deposit' ? 'Deposit' : 'Withdrawal'} rejected${adminNote ? `: ${adminNote}` : ''}`,
        'rejected'
      );
    } catch (error) {
      console.error('Reject transaction error:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };
  
  const processBet = async (amount: number, isWin: boolean) => {
    if (!user) throw new Error('User must be logged in');
    if (balance < amount && !isWin) throw new Error('Insufficient funds');
    if (!hasDeposited) throw new Error('Please make a deposit first');
    
    setLoading(true);
    try {
      if (isWin) {
        const winAmount = amount * 2;
        const commission = winAmount * COMMISSION_RATE;
        const netWinnings = winAmount - commission;
        
        setBalance(prev => prev + netWinnings);
        addTransaction('bet-win', netWinnings, `Won $${netWinnings.toFixed(2)} (Commission: $${commission.toFixed(2)})`);
        addTransaction('commission', -commission, `Commission paid to platform: $${commission.toFixed(2)}`);
        
        console.log(`Commission of $${commission.toFixed(2)} sent to ${PLATFORM_WALLET}`);
      } else {
        setBalance(prev => prev - amount);
        addTransaction('bet-loss', -amount, `Lost $${amount.toFixed(2)} on bet`);
      }
    } catch (error) {
      console.error('Bet processing error:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  return (
    <WalletContext.Provider
      value={{
        balance,
        transactions,
        transactionRequests,
        deposit,
        withdraw,
        processBet,
        approveTransaction,
        rejectTransaction,
        claimReward,
        loading,
        hasUnlockedBonus,
        hasDeposited,
        bonusAmount
      }}
    >
      {children}
    </WalletContext.Provider>
  );
};

export const useWallet = () => {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
};